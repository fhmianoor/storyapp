export default {
  getToken() {
    return localStorage.getItem('token');
  }
}
  