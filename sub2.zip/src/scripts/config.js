const config = {
  BASE_URL: 'https://story-api.dicoding.dev/v1',
};

export default config;